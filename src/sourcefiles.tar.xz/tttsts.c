#include <raylib.h>

int main(){
	InitWindow(800, 600, "hi");
	CloseWindow();
}
